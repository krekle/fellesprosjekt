package gruppe9.kalender.client;

public interface ApiCaller {

	public void callBack(CalResponse response);
	
}
